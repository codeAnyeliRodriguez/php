<?php 
$consulta = "SELECT * FROM contactos";
include("php/tabla-resultados.php");
?>